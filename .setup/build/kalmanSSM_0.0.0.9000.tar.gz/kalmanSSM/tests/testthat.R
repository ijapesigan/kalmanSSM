library(testthat)
library(kalmanSSM)

test_check("kalmanSSM")
